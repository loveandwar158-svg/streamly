STREAMLY — clickable front-end preview

Open index.html in a modern web browser. No installation is required.

Included demo interactions:
- Browse video cards and filter by category
- Search sample videos
- Open a video preview panel
- Like, subscribe, share, and add temporary comments
- Add a local video preview card
- View a sample creator studio and admin dashboard

IMPORTANT LIMITATIONS
This is a front-end prototype only. It does not yet have real user accounts, secure authentication, permanent database storage, server-side video uploads/streaming, notifications, creator payouts, moderation workflows, or production security. Demo changes are temporary and may be lost on refresh. The admin dashboard is illustrative, not protected.

Next production phase: connect authentication, database, object/video storage, upload processing, moderation, and deploy to a hosting provider. Do not expose this demo admin page publicly as an actual admin system.
